class Media:
    def __init__(self, id, title, release_date, genre, synopsis, image_path):
        self.id = id
        self.title = title
        self.release_date = release_date
        self.genre = genre
        self.synopsis = synopsis
        self.image_path = image_path